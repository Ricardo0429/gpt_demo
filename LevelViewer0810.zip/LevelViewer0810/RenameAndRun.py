import os
import subprocess
import time


dbdir = "./LDB"
cwd = os.getcwd()

for dpath, dnames, fnames in os.walk(dbdir):
    os.chdir(dpath)
    for filename in fnames:
        if "_" in filename:
            last = filename.rfind('_') + 1
            os.rename(filename, filename[last:])

os.chdir(cwd)
time.sleep(0.5)

subprocess.call(["./LevelDBDumper.exe", "-d", dbdir, "-t", "json", "-o", "./", ""])